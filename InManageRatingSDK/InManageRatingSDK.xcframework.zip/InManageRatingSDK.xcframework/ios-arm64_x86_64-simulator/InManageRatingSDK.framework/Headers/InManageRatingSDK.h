//
//  InManageRatingSDK.h
//  InManageRatingSDK
//
//  Created by Omer Cohen on 21/01/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for InManageRatingSDK.
FOUNDATION_EXPORT double InManageRatingSDKVersionNumber;

//! Project version string for InManageRatingSDK.
FOUNDATION_EXPORT const unsigned char InManageRatingSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <InManageRatingSDK/PublicHeader.h>


